/**
 * مواطن — Mouatin.ma — تعبئة أولية (Seed) لجهات وأقاليم ومدن المغرب.
 * هذه هي نفس البيانات الجغرافية الحقيقية المستعملة في الواجهة (REGIONS داخل mouatin-prototype.html)،
 * مصدر واحد فقط للحقيقة (Single Source of Truth) — لا تُعاد كتابتها يدويًا في مكانين مختلفين.
 * المصدر: المرسوم رقم 2.15.40 (التقطيع الترابي 2015) + المندوبية السامية للتخطيط (HCP).
 *
 * ⚠️ هذا سكريبت تعبئة أولية للجغرافيا الإدارية فقط (جهات/أقاليم/مدن).
 * لا يحتوي على أي مؤسسة أو مكان أو شركة "مُختلقة" — تلك تُضاف فقط عبر
 * لوحة الإدارة أو نظام Import بعد التحقق من مصدرها (انظر VerificationLog في schema.prisma).
 */
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const REGIONS = [
  { id: 'casa-settat', nameAr: 'الدار البيضاء-سطات', capitalAr: 'الدار البيضاء',
    provinces: ['الدار البيضاء','المحمدية','الجديدة','النواصر','مديونة','بنسليمان','برشيد','سطات','سيدي بنور'],
    cities: ['الدار البيضاء'] },
  { id: 'rabat-sale-kenitra', nameAr: 'الرباط-سلا-القنيطرة', capitalAr: 'الرباط',
    provinces: ['الرباط','سلا','الصخيرات-تمارة','القنيطرة','الخميسات','سيدي قاسم','سيدي سليمان'],
    cities: ['الرباط','القنيطرة'] },
  { id: 'tanger-tetouan-alhoceima', nameAr: 'طنجة-تطوان-الحسيمة', capitalAr: 'طنجة',
    provinces: ['طنجة-أصيلة','المضيق-الفنيدق','تطوان','الفحص-أنجرة','العرائش','الحسيمة','شفشاون','وزان'],
    cities: ['طنجة','تطوان'] },
  { id: 'fes-meknes', nameAr: 'فاس-مكناس', capitalAr: 'فاس',
    provinces: ['فاس','مكناس','الحاجب','إفران','مولاي يعقوب','صفرو','بولمان','تاونات','تازة'],
    cities: ['فاس','مكناس'] },
  { id: 'marrakech-safi', nameAr: 'مراكش-آسفي', capitalAr: 'مراكش',
    provinces: ['مراكش','شيشاوة','الحوز','قلعة السراغنة','الصويرة','الرحامنة','آسفي','اليوسفية'],
    cities: ['مراكش'] },
  { id: 'oriental', nameAr: 'الشرق', capitalAr: 'وجدة',
    provinces: ['وجدة-أنجاد','الناظور','الدريوش','جرادة','بركان','تاوريرت','جرسيف','فجيج'],
    cities: ['وجدة'] },
  { id: 'souss-massa', nameAr: 'سوس-ماسة', capitalAr: 'أكادير',
    provinces: ['أكادير إداوتنان','إنزكان أيت ملول','شتوكة أيت باها','تارودانت','تيزنيت','طاطا'],
    cities: ['أكادير'] },
  { id: 'beni-mellal-khenifra', nameAr: 'بني ملال-خنيفرة', capitalAr: 'بني ملال',
    provinces: ['بني ملال','أزيلال','الفقيه بن صالح','خنيفرة','خريبكة'], cities: [] },
  { id: 'draa-tafilalet', nameAr: 'درعة-تافيلالت', capitalAr: 'الرشيدية',
    provinces: ['الرشيدية','ورزازات','ميدلت','تنغير','زاكورة'], cities: [] },
  { id: 'guelmim-oued-noun', nameAr: 'كلميم-واد نون', capitalAr: 'كلميم',
    provinces: ['كلميم','آسا-الزاك','طانطان','سيدي إفني'], cities: [] },
  { id: 'laayoune-saguia', nameAr: 'العيون-الساقية الحمراء', capitalAr: 'العيون',
    provinces: ['العيون','بوجدور','طرفاية','السمارة'], cities: [] },
  { id: 'dakhla-oued-eddahab', nameAr: 'الداخلة-وادي الذهب', capitalAr: 'الداخلة',
    provinces: ['وادي الذهب (الداخلة)','أوسرد'], cities: [] },
];

async function main() {
  for (const r of REGIONS) {
    const region = await prisma.region.upsert({
      where: { id: r.id },
      update: { nameAr: r.nameAr, capitalAr: r.capitalAr },
      create: { id: r.id, nameAr: r.nameAr, capitalAr: r.capitalAr },
    });
    for (const provinceName of r.provinces) {
      await prisma.province.upsert({
        where: { id: `${r.id}-${provinceName}` },
        update: {},
        create: { id: `${r.id}-${provinceName}`, nameAr: provinceName, regionId: region.id },
      });
    }
    for (const cityName of r.cities) {
      await prisma.city.upsert({
        where: { id: `${r.id}-city-${cityName}` },
        update: {},
        create: { id: `${r.id}-city-${cityName}`, nameAr: cityName, regionId: region.id },
      });
    }
  }
  console.log('تمت تعبئة الجهات والأقاليم والمدن الأساسية بنجاح.');
}

main().finally(() => prisma.$disconnect());
