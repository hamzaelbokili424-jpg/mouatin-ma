# Mouatin.ma Backend — نقطة انطلاق حقيقية

هذا مشروع NestJS + Prisma حقيقي وقابل للتشغيل، مبني من الملفات التي سلّمتها سابقًا
(`schema.prisma`, `cities.controller.ts`, `ai-search.service.ts`) + الأسلاك الناقصة
(`main.ts`, `app.module.ts`, `prisma.service.ts`, `package.json`).

## ⚠️ بصدق: ما تم وما لم يتم هنا
- هذا الكود **لم يُشغَّل أو يُختبر فعليًا في هذه المحادثة** — بيئة الشات هذه بدون اتصال
  بالإنترنت، فلا يمكنها تشغيل `npm install` أو تحميل Docker images.
- الكود نفسه صحيح بنيويًا (نمط NestJS/Prisma قياسي)، لكن التشغيل الفعلي والاختبار
  يجب أن يحدثا في بيئة حقيقية — **Claude Code** أو جهازك مباشرة.

## طريقة التشغيل الحقيقية (على جهازك أو في Claude Code)

```bash
# 1. تثبيت الحزم
npm install

# 2. تشغيل قاعدة بيانات حقيقية محليًا
docker compose up -d postgres redis

# 3. نسخ متغيرات البيئة
cp .env.example .env
# عدّل DATABASE_URL في .env إذا لزم، القيمة الافتراضية تطابق docker-compose.yml:
# DATABASE_URL=postgresql://mouatin:mouatin_dev_only_change_me@localhost:5432/mouatin

# 4. إنشاء الجداول فعليًا من schema.prisma
npx prisma migrate dev --name init

# 5. تعبئة الجغرافيا الحقيقية (جهات/أقاليم/مدن المغرب)
npm run seed:regions

# 6. تشغيل الخادم
npm run start:dev

# 7. تحقق أنه يعمل فعليًا (وليس افتراضًا)
curl http://localhost:3000/health
curl http://localhost:3000/regions
```

## الخطوة التالية المنطقية بعد التشغيل الناجح
1. ربط `mouatin-prototype.html` (الواجهة الحالية) بهذا الـAPI بدل البيانات المحلية الثابتة.
2. إضافة Authentication حقيقي (JWT).
3. تعبئة أول مجموعة بيانات حقيقية موثقة (مصدر + رابط + تاريخ تحقق) بدل بيانات العرض.
4. عندها فقط ننتقل لـ AI/RAG — بعد أن يصبح هناك بيانات حقيقية يبحث فيها.
