/**
 * مواطن — Mouatin.ma — مثال حقيقي لـ /regions و /cities (NestJS)
 * يوسّع الـAPI الموصوف في TECHNICAL_ARCHITECTURE.md بدون حذف أي مسار موجود.
 */
import { Controller, Get, Query, Param } from '@nestjs/common';
import { PrismaService } from './prisma.service'; // افتراضي — حسب بنية المشروع الحقيقية

@Controller()
export class CitiesController {
  constructor(private prisma: PrismaService) {}

  @Get('regions')
  async listRegions() {
    return this.prisma.region.findMany({ include: { provinces: true, cities: true } });
  }

  @Get('cities')
  async listCities(@Query('region') regionId?: string, @Query('q') q?: string) {
    return this.prisma.city.findMany({
      where: {
        ...(regionId ? { regionId } : {}),
        ...(q ? { nameAr: { contains: q } } : {}),
      },
      include: { region: true, province: true },
    });
  }

  @Get('cities/:id')
  async cityDetail(@Param('id') id: string) {
    // صفحة المدينة: كل المعطيات المرتبطة بها (مؤسسات، أماكن، فرص) حسب الطلب في القسم 5
    return this.prisma.city.findUnique({
      where: { id },
      include: {
        region: true,
        institutions: { include: { source: true } },
        locations: { include: { source: true } },
      },
    });
  }
}
