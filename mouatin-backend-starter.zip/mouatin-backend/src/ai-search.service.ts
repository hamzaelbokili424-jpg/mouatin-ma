/**
 * مواطن — Mouatin.ma
 * مثال حقيقي (Backend / NestJS) لكيفية ربط: Intent Detection → البحث في قاعدة البيانات
 * → (عند الحاجة) بحث ويب حي → RAG → صياغة الجواب بالـ LLM → المصادر.
 *
 * ⚠️ هذا الملف تصميم/مثال قابل للتشغيل بعد تركيبه في مشروع NestJS حقيقي،
 * وليس جزءًا من الواجهة الأمامية. لا يوضع في المتصفح أبدًا لأنه يستعمل مفاتيح سرية.
 * كل المفاتيح تُقرأ من process.env (انظر .env.example) — لا يوجد أي مفتاح مكتوب هنا.
 */

import { Injectable } from '@nestjs/common';

interface VerifiedAnswer {
  found: boolean;
  title?: string;
  summary?: string;
  sourceName?: string;
  sourceUrl?: string;
  lastVerifiedAt?: string;
  needsWebSearch?: boolean;
}

@Injectable()
export class AiSearchService {

  /**
   * الخطوة 1: تصنيف نية السؤال (جواز، بطاقة، تكوين، بحث عن شركة، بحث عن منحة...)
   * في نسخة حقيقية هذا يمكن أن يكون تصنيف بسيط بالكلمات المفتاحية،
   * أو نموذج تصنيف مخصص، أو استدعاء أولي خفيف للـ LLM.
   */
  detectIntent(question: string): 'service' | 'company_search' | 'opportunity_search' | 'place_search' {
    // مثال مبسط فقط — المنطق الحقيقي يعيش هنا
    if (/شركة|شركات|company|entreprise/i.test(question)) return 'company_search';
    if (/منحة|فرصة|دعم|opportunity/i.test(question)) return 'opportunity_search';
    if (/فين|أقرب|مركز|centre|nearest/i.test(question)) return 'place_search';
    return 'service';
  }

  /**
   * الخطوة 2: البحث أولًا في قاعدة البيانات الداخلية (المصادر الموثقة مسبقًا).
   */
  async searchInternalDb(question: string, city?: string): Promise<VerifiedAnswer> {
    // TODO: استعلام حقيقي على جدول services / sources عبر Prisma/TypeORM
    // مثال توضيحي فقط:
    return { found: false, needsWebSearch: true };
  }

  /**
   * الخطوة 3: إذا لم توجد معلومة كافية أو كانت المعلومة من النوع الحساس للتحديث
   * (منح، مواعيد، أسعار، عروض شركات)، نجري بحثًا حيًا عبر مزوّد بحث حقيقي.
   * المفتاح يُقرأ من process.env فقط — لا يوضع هنا ولا في الواجهة الأمامية.
   */
  async liveWebSearch(query: string, city?: string): Promise<Array<{
    title: string; url: string; snippet: string;
  }>> {
    const apiKey = process.env.WEB_SEARCH_API_KEY;
    if (!apiKey) {
      // لا مفتاح مُهيأ بعد — نرجع نتيجة فارغة بدل اختلاق بيانات
      return [];
    }
    const provider = process.env.WEB_SEARCH_PROVIDER || 'default';
    // TODO: استدعاء حقيقي لمزوّد البحث (Google Custom Search API, Bing, Brave Search API...)
    // const res = await fetch(`https://provider.example/search?q=${encodeURIComponent(query + ' ' + (city||''))}`, {
    //   headers: { Authorization: `Bearer ${apiKey}` }
    // });
    // return await res.json();
    return [];
  }

  /**
   * الخطوة 4: بناء رابط "فتح في Google Maps" — لا يحتاج مفتاح API لأنه رابط بحث عادي.
   * مفتاح Maps API يصير ضروريًا فقط لعرض خريطة تفاعلية حقيقية (Maps JavaScript API / Mapbox).
   */
  buildGoogleMapsUrl(placeName: string, city?: string): string {
    const q = encodeURIComponent(`${placeName} ${city || ''}`.trim());
    return `https://www.google.com/maps/search/?api=1&query=${q}`;
  }

  /**
   * الخطوة 5: تمرير فقط المحتوى الموثّق (من القاعدة أو من نتائج البحث الحي) إلى LLM
   * لإعادة الصياغة بلغة المستخدم (دارجة/عربية/فرنسية)، مع منعه من اختلاق أي معلومة إضافية.
   */
  async composeAnswerWithLLM(verifiedContext: string, question: string, lang: string): Promise<string> {
    const apiKey = process.env.LLM_API_KEY;
    if (!apiKey) throw new Error('LLM_API_KEY غير مُهيأ في البيئة');

    const systemPrompt = `
أنت مساعد "مواطن". أجب فقط بالاعتماد على المعطيات الموثقة التالية، بلغة المستخدم (${lang}).
ممنوع إضافة أي معلومة، اسم شركة، رقم هاتف، أو عنوان غير موجود في المعطيات.
إذا كانت المعطيات غير كافية، صرّح بذلك بوضوح بدل التخمين.

المعطيات الموثقة:
${verifiedContext}
`.trim();

    // TODO: استدعاء حقيقي لـ Anthropic API أو أي مزوّد LLM باستخدام LLM_API_KEY من process.env
    // const res = await fetch('https://api.anthropic.com/v1/messages', { ... headers: { 'x-api-key': apiKey } ... });
    return '(مثال) نص الجواب المُصاغ هنا بناءً على المعطيات الموثقة فقط.';
  }

  /**
   * نقطة الدخول الكاملة — تطبق تسلسل RAG المذكور في TECHNICAL_ARCHITECTURE.md حرفيًا:
   * سؤال → Intent → بحث DB → (عند الحاجة) بحث حي → LLM → جواب + مصادر + تاريخ التحقق.
   */
  async answer(question: string, lang: string, city?: string) {
    const intent = this.detectIntent(question);
    const dbResult = await this.searchInternalDb(question, city);

    if (dbResult.found) {
      return {
        answer: dbResult.summary,
        source: { name: dbResult.sourceName, url: dbResult.sourceUrl },
        lastVerifiedAt: dbResult.lastVerifiedAt,
        intent,
      };
    }

    if (dbResult.needsWebSearch) {
      const webResults = await this.liveWebSearch(question, city);
      if (webResults.length === 0) {
        return {
          answer: 'لم أجد مصدرًا موثوقًا يؤكد هذه المعلومة حاليًا.',
          source: null,
          lastVerifiedAt: null,
          intent,
        };
      }
      const context = webResults.map(r => `- ${r.title}: ${r.snippet} (${r.url})`).join('\n');
      const composed = await this.composeAnswerWithLLM(context, question, lang);
      return {
        answer: composed,
        sources: webResults.map(r => ({ name: r.title, url: r.url })),
        lastVerifiedAt: new Date().toISOString().slice(0, 10),
        intent,
      };
    }

    return {
      answer: 'لم أجد مصدرًا موثوقًا يؤكد هذه المعلومة حاليًا.',
      source: null,
      lastVerifiedAt: null,
      intent,
    };
  }
}
