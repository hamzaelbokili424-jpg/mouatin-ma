import { Module, Controller, Get } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { CitiesController } from './cities.controller';
import { AiSearchService } from './ai-search.service';

// نقطة فحص حقيقية — لو فشل الاتصال بقاعدة البيانات يفشل هذا الطلب فعليًا
// (وليس زعمًا بأن كل شيء "يعمل")
@Controller('health')
class HealthController {
  constructor(private prisma: PrismaService) {}
  @Get()
  async check() {
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return { status: 'ok', database: 'connected' };
    } catch (e) {
      return { status: 'degraded', database: 'unreachable', error: (e as Error).message };
    }
  }
}

@Module({
  controllers: [CitiesController, HealthController],
  providers: [PrismaService, AiSearchService],
})
export class AppModule {}
